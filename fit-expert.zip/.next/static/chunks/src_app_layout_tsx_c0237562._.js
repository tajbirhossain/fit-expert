(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__126defe6._.css",
  "static/chunks/node_modules_9445887e._.js",
  "static/chunks/src_components_animated_LenisProvider_tsx_d994140f._.js"
],
    source: "dynamic"
});

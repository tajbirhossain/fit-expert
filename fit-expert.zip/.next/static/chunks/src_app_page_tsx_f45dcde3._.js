(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_f0f2dd12._.js",
  "static/chunks/node_modules_a21d6526._.js",
  "static/chunks/node_modules_swiper_865b38a0._.css"
],
    source: "dynamic"
});

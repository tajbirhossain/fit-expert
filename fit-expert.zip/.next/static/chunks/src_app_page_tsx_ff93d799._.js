(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_e5b9fd02._.js",
  "static/chunks/node_modules_e7db6251._.js",
  "static/chunks/node_modules_swiper_865b38a0._.css"
],
    source: "dynamic"
});
